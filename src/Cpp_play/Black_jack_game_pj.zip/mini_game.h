#ifndef mini_game
#define mini_game

using namespace std;


void play_T();


#endif