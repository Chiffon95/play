#ifndef Card_shape
#define Card_shape
using namespace std;

void showPlayerCard();

void showDealerCard();

void showPlayerCard(char* s, int n);

void previousCard(int s, int n);

void dealerCard(char* s, int n);

#endif // !Card_shape